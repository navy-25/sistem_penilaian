<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        Version 1.0
    </div>
    Copyright &copy; 2021 | by D'Fixers
</footer><?php /**PATH D:\Master\xampp\htdocs\sistem_penilaian\resources\views/includes/footer.blade.php ENDPATH**/ ?>