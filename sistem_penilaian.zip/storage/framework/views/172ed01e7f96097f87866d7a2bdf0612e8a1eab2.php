<!-- teks statis -->
<?php
    // head
    $tittle = "Sistem Penilaian";
    $sub_tittle = "Beranda";

    // fitur name
    $nama_menu_1 = "Beranda";
    $nama_menu_2 = "Akun Siswa";
    $nama_menu_3 = "Buat Kelas";
    $nama_menu_4 = "Buat Soal";
    $nama_menu_5 = "SOP Nilai";
    $nama_menu_6 = "Rekab Nilai";

    // icon menu
    $icon_menu_1 = "home";
    $icon_menu_2 = "user";
    $icon_menu_3 = "graduation-cap";
    $icon_menu_4 = "question";
    $icon_menu_5 = "book";
    $icon_menu_6 = "file-alt";
?><?php /**PATH D:\Master\xampp\htdocs\sistem_penilaian\resources\views/includes/variable.blade.php ENDPATH**/ ?>