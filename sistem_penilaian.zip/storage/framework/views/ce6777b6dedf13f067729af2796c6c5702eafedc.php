<!-- teks statis -->
<?php
    // head
    $tittle = "Sistem Penilaian";

    // fitur name
    $nama_menu_1 = "Beranda";
    $nama_menu_2 = "Akun Siswa";
    $nama_menu_3 = "Kelas";
    $nama_menu_4 = "Input Nilai";
    $nama_menu_5 = "Variabel Praktik";
    $nama_menu_6 = "Rekab Nilai";
    $nama_menu_7 = "Pengaturan";

    // icon menu
    $icon_menu_1 = "home";
    $icon_menu_2 = "user";
    $icon_menu_3 = "graduation-cap";
    $icon_menu_4 = "award";
    $icon_menu_5 = "award";
    $icon_menu_6 = "file-alt";
    $icon_menu_7 = "sliders-h";

    //link routes
    $link_menu_1 = "/admin/beranda";
    $link_menu_2 = "/admin/akun-siswa";
    $link_menu_3 = "/admin/kelas";
    $link_menu_4 = "/admin/soal";
    $link_menu_5 = "/admin/nilai";
    $link_menu_6 = "/admin/rekab";
    $link_menu_7 = "/admin/pengaturan";
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title><?php echo e($tittle); ?> | <?php echo $__env->yieldContent('sub_tittle'); ?></title>
        <!-- Tell the browser to be responsive to screen width -->
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Font Awesome -->
        <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free/css/all.min.css')); ?>">
        <!-- Ionicons -->
        <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css')}}">
        <?php echo $__env->yieldContent('boostrap'); ?>        
        <!-- overlayScrollbars -->
        <link rel="stylesheet" href="<?php echo e(asset('dist/css/adminlte.min.css')); ?>">
        <!-- Google Font: Source Sans Pro -->
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

        <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->
    </head>
    <body class="hold-transition sidebar-mini">
        <!-- Site wrapper -->
        <div class="wrapper">
            <!-- Navbar -->
            <nav class="main-header navbar navbar-expand navbar-white navbar-light">
                <!-- Left navbar links -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                    </li>
                </ul>
                

                <!-- SEARCH FORM -->
                <?php echo $__env->yieldContent('search'); ?>
                

                <!-- Right navbar links -->
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <!-- PRINT BUTTON -->
                        <?php echo $__env->yieldContent('print'); ?>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" title="Pengaturan Akun" href="/admin/pengaturan">
                            <i class="fas fa-user-cog"></i>
                            <!-- <span class="badge badge-danger navbar-badge">3</span> -->
                        </a>
                    </li>
                    <li class="nav-item">
                        <li class="nav-item dropdown">
                            <a class="nav-link" data-toggle="dropdown" href="#">
                                <i class="fas fa-th-large"></i>
                                <!-- <span class="badge badge-danger navbar-badge">3</span> -->
                            </a>
                            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                            <a href="#" class="dropdown-item">
                                <div class="media">
                                    <img src="<?php echo e(asset('../../dist/img/user1-128x128.jpg')); ?>" alt="User Avatar" class="img-size-50 mr-3 img-circle">
                                    <div class="media-body">
                                        <h3 class="dropdown-item-title">
                                        Nafi
                                        <span class="float-right text-sm text-danger"><i class="fas fa-star"></i></span>
                                        </h3>
                                        <p class="text-sm">XII Multimedia</p>
                                    </div>
                                </div>
                            </a>
                            <div class="dropdown-divider"></div>
                            
                            <div class="dropdown-divider"></div>
                                <a href="/" class="dropdown-item dropdown-footer">
                                    Logout
                                </a>
                            </div>
                        </li>
                    </li>
                </ul>
            </nav>
            <!-- /.navbar -->

            <!-- Main Sidebar Container -->
            <aside class="main-sidebar sidebar-dark-primary elevation-4">
                <!-- Sidebar -->
                <div class="sidebar">
                <!-- Sidebar user (optional) -->
                <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                    <div class="image">
                    <img src="<?php echo e(asset('../../dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
                    </div>
                    <div class="info">
                    <a href="#" class="d-block">Admin</a>
                    </div>
                </div>

                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <li class="nav-item">
                            <a href="<?php echo e($link_menu_1); ?>" class="nav-link <?php echo $__env->yieldContent('menu_1'); ?>">
                            <i class="nav-icon fas fa-<?php echo e($icon_menu_1); ?>"></i>
                            <p>
                                <?php echo e($nama_menu_1); ?>

                                <!-- <span class="right badge badge-danger">New</span> -->
                            </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e($link_menu_2); ?>" class="nav-link <?php echo $__env->yieldContent('menu_2'); ?>">
                            <i class="nav-icon fas fa-<?php echo e($icon_menu_2); ?>"></i>
                            <p>
                                <?php echo e($nama_menu_2); ?>

                                <!-- <span class="right badge badge-danger">New</span> -->
                            </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e($link_menu_3); ?>" class="nav-link  <?php echo $__env->yieldContent('menu_3'); ?>">
                            <i class="nav-icon fas fa-<?php echo e($icon_menu_3); ?>"></i>
                            <p>
                                <?php echo e($nama_menu_3); ?>

                                <!-- <span class="right badge badge-danger">New</span> -->
                            </p>
                            </a>
                        </li>
                        <!-- <li class="nav-item">
                            <a href="<?php echo e($link_menu_4); ?>" class="nav-link  <?php echo $__env->yieldContent('menu_4'); ?>">
                            <i class="nav-icon fas fa-<?php echo e($icon_menu_4); ?>"></i>
                            <p>
                                <?php echo e($nama_menu_4); ?>

                            </p>
                            </a>
                        </li> -->
                        <li class="nav-item">
                            <a href="<?php echo e($link_menu_5); ?>" class="nav-link  <?php echo $__env->yieldContent('menu_5'); ?>">
                            <i class="nav-icon fas fa-<?php echo e($icon_menu_5); ?>"></i>
                            <p>
                                <?php echo e($nama_menu_5); ?>

                                <!-- <span class="right badge badge-danger">New</span> -->
                            </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e($link_menu_6); ?>" class="nav-link  <?php echo $__env->yieldContent('menu_6'); ?>">
                            <i class="nav-icon fas fa-<?php echo e($icon_menu_6); ?>"></i>
                            <p>
                                <?php echo e($nama_menu_6); ?>

                                <!-- <span class="right badge badge-danger">New</span> -->
                            </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e($link_menu_7); ?>" class="nav-link  <?php echo $__env->yieldContent('menu_7'); ?>">
                            <i class="nav-icon fas fa-<?php echo e($icon_menu_7); ?>"></i>
                            <p>
                                <?php echo e($nama_menu_7); ?>

                                <!-- <span class="right badge badge-danger">New</span> -->
                            </p>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
                </div>
                <!-- /.sidebar -->
            </aside>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- /.content-wrapper -->

            <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Control Sidebar -->
            <aside class="control-sidebar control-sidebar-dark">
                <!-- Control sidebar content goes here -->
            </aside>
        <!-- /.control-sidebar -->
        </div>
        <!-- ./wrapper -->

        <!-- jQuery -->
        <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
        <!-- Bootstrap 4 -->
        <script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script>
        <!-- AdminLTE for demo purposes -->
        <script src="<?php echo e(asset('dist/js/demo.js')); ?>"></script>
        
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

        <?php echo $__env->yieldContent('script'); ?>
        <!-- <script>
            $('.logout-confirm').on('click', function (event) {
                event.preventDefault();
                const url = $(this).attr('href');
                swal({
                    title: 'Apakah anda yakin keluar ?',
                    // text: 'Akun yang sudah dihapus tidak bisa di onlinekan kembali',
                    icon: 'warning',
                    buttons: ["Batalkan", "Keluar"],
                }).then(function(value) {
                    if (value) {
                        window.location.href = url;
                    }
                });
            });
        </script> -->
    </body>
</html>
<?php /**PATH D:\Master\xampp\htdocs\sistem_penilaian\resources\views/layouts/master.blade.php ENDPATH**/ ?>