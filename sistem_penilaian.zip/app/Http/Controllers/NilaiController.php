<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NilaiController extends Controller
{
    public function index()
    {
        return view('nilai.index');
    }
    public function variabelNilai()
    {
        return view('nilai.kelolaPenilaian');
    }
}
