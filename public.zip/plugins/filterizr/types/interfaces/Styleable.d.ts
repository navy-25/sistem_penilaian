import StyledFilterizrElement from '../../StyledFilterizrElement';
import StyledFilterizrElements from '../../StyledFilterizrElements';
export interface Styleable {
    readonly styles: StyledFilterizrElement | StyledFilterizrElements;
}
